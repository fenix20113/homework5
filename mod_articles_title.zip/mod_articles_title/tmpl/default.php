<?php
    defined('_JEXEC') or die ('Restricted access');

?>


<?php

foreach($art_title as $title){
    echo $title."<br>";
}


?>